"""Check sanitized funding schemas, coverage, accounting, and clean replay."""
from __future__ import annotations
import argparse
import csv
from decimal import Decimal, ROUND_HALF_UP, localcontext
from pathlib import Path
from collections import defaultdict, Counter
import json
from rebuild_funding_exposures import COMPONENTS, METRICS, WINDOW_FIELDS, rebuild


def read(path):
    with path.open(encoding="utf-8",newline="") as f:
        r=csv.DictReader(f)
        fields=r.fieldnames
        assert len(fields)==len(set(fields))
        data=list(r)
        assert all(None not in x and all(v is not None for v in x.values()) for x in data)
        return fields,data


def check(bundle):
    if not __debug__:
        raise RuntimeError("Verification requires Python assertions enabled; do not use -O")
    af,annual=read(bundle/'data/institution_fy_funding.csv')
    assert af==['institution_id','fiscal_year','aggregation_scope','ownership_authority','source_complete','exposure_status','funding_state',*METRICS]
    wf,window=read(bundle/'data/institution_completion_year_degree_funding_exposure.csv')
    assert wf==WINDOW_FIELDS
    uf,universe=read(bundle/'data/funding_exposure_institutions.csv')
    assert uf==['institution_id','ownership_status','institution_role']
    rf,routes=read(bundle/'data/funding_ownership_routes.csv')
    assert rf==['institution_id','completion_year','fiscal_year','funding_row_institution_id','selection_basis']
    pf,pr=read(bundle/'data/brdpi_2023_base.csv')
    assert pf==['fiscal_year','brdpi_2023_base_100']
    gf,groups=read(bundle/'data/activity_code_groups.csv')
    assert gf==['activity','a3_group','classification_note']
    sf,source=read(bundle/'data/nih_source_fy_accounting.csv')
    assert sf==['fiscal_year','accounting_universe','component','application_fy_count','contribution_count','nominal_usd','real_2023_usd']
    identities={r['institution_id'] for r in read(bundle/'data/analysis_institution_identity.csv')[1]}
    annual_idx={(r['institution_id'],r['fiscal_year']):r for r in annual}
    assert len(annual_idx)==len(annual)==19114
    expected_fys=set(map(str,range(2005,2024)))
    by_inst=defaultdict(set)
    for r in annual:
        assert r['institution_id'] in identities and r['source_complete']=='1'
        by_inst[r['institution_id']].add(r['fiscal_year'])
    assert all(fys==expected_fys for fys in by_inst.values())
    assert len(by_inst)==1006
    assert len(universe)==951 and len({r['institution_id'] for r in universe})==951
    assert all(r['institution_id'] in identities for r in universe)
    wi={(r['institution_id'],r['completion_year'],r['degree_level']):r for r in window}
    assert len(wi)==len(window)==26628
    assert set(wi)=={(r['institution_id'],str(y),degree) for r in universe for y in range(2010,2024) for degree in ('masters','doctoral')}
    prices={r['fiscal_year']:Decimal(r['brdpi_2023_base_100']) for r in pr}
    for collection in (annual,window):
        for r in collection:
            if r['exposure_status']=='unresolved_ownership':
                assert r['funding_state']=='unresolved_ownership' and all(r[f]=='' for f in METRICS)
                continue
            assert r['exposure_status']=='resolved' and all(r[f]!='' for f in METRICS)
            assert r['funding_state']==('positive' if int(r['F_combined']) else 'certified_zero')
            for c in COMPONENTS:
                assert int(r['F_'+c])>=0 and int(r['nominal_'+c+'_usd'])>=0 and int(r['contributions_'+c])>=0
                assert (int(r['F_'+c])==0)==(int(r['nominal_'+c+'_usd'])==0)==(Decimal(r['real_'+c+'_2023_usd'])==0)
            assert int(r['F_NIDA'])+int(r['F_NIAAA'])-int(r['F_both_IC'])==int(r['F_combined'])
            for base in ('F_','nominal_','contributions_'):
                suffix='_usd' if base=='nominal_' else ''
                assert sum(int(r[base+c+suffix]) for c in COMPONENTS[3:])==int(r[base+'combined'+suffix])
            assert int(r['nominal_NIDA_usd'])+int(r['nominal_NIAAA_usd'])==int(r['nominal_combined_usd'])
    for r in annual:
        if r['exposure_status']!='resolved': continue
        with localcontext() as ctx:
            ctx.prec=50
            for c in COMPONENTS:
                calc=(Decimal(r['nominal_'+c+'_usd'])*prices['2023']/prices[r['fiscal_year']]).quantize(Decimal('.01'),rounding=ROUND_HALF_UP)
                assert calc==Decimal(r['real_'+c+'_2023_usd'])
    assert len({(r['institution_id'],r['completion_year'],r['fiscal_year'],r['funding_row_institution_id']) for r in routes})==len(routes)==66672
    assert all((r['funding_row_institution_id'],r['fiscal_year']) in annual_idx and r['institution_id'] in identities for r in routes)
    source_idx={(r['fiscal_year'],r['accounting_universe'],r['component']):r for r in source}
    assert len(source_idx)==len(source)==513
    for fy in expected_fys:
        direct=[r for r in annual if r['fiscal_year']==fy and r['aggregation_scope']=='direct_source_owner' and r['exposure_status']=='resolved']
        for c in COMPONENTS:
            total=source_idx[fy,'all_certified_source',c]
            assigned=source_idx[fy,'assigned_direct_source',c]
            unassigned=source_idx[fy,'unassigned_source',c]
            for field in ('application_fy_count','contribution_count','nominal_usd'):
                assert int(total[field])==int(assigned[field])+int(unassigned[field])
            for public,field in [('F_'+c,'application_fy_count'),('contributions_'+c,'contribution_count'),('nominal_'+c+'_usd','nominal_usd')]:
                assert sum(int(r[public]) for r in direct)==int(assigned[field])
    assert sum(int(r['nominal_usd']) for r in source if r['accounting_universe']=='all_certified_source' and r['component']=='combined')==28386333289
    assert sum(int(r['contribution_count']) for r in source if r['accounting_universe']=='all_certified_source' and r['component']=='combined')==69382
    assert len(groups)==104 and {r['a3_group'] for r in groups}==set(COMPONENTS[3:])
    dictionary=read(bundle/'dictionaries/funding_data_dictionary.csv')[1]
    described={(r['dataset'],r['column']) for r in dictionary}
    for filename,fields in [('institution_fy_funding.csv',af),('institution_completion_year_degree_funding_exposure.csv',wf),('funding_exposure_institutions.csv',uf),('funding_ownership_routes.csv',rf),('brdpi_2023_base.csv',pf),('activity_code_groups.csv',gf),('nih_source_fy_accounting.csv',sf)]:
        assert all(('data/'+filename,f) in described for f in fields)
    assert rebuild(bundle)==(bundle/'data/institution_completion_year_degree_funding_exposure.csv').read_bytes()
    return dict(status='passed',annual_rows=len(annual),annual_institutions=len(by_inst),
                funding_window_rows=len(window),funding_window_institutions=len(universe),
                annual_unknown_rows=sum(r['exposure_status']!='resolved' for r in annual),
                window_unknown_rows=sum(r['exposure_status']!='resolved' for r in window),
                annual_states=dict(Counter(r['funding_state'] for r in annual)),
                window_states=dict(Counter(r['funding_state'] for r in window)),
                source_nominal_usd=28386333289,source_contributions=69382,
                source_accounting_conserved=True,complete_grid_not_observed_outcome_cells=True,
                annual_brdpi_recomputed=True,exposure_replay_byte_equal=True,
                recorded_prior_private_reference_validation='At candidate construction, all 37 funding component fields matched 13,293 adopted cells. Current annualized and log predictors matched 13,293 current institutional cells. Bound source hashes are recorded in funding_sources.csv.',
                private_reference_comparison_performed_in_this_run=False,
                independent_full_model_reproduction=False)


if __name__=='__main__':
    if not __debug__:
        raise RuntimeError("Verification requires Python assertions enabled; do not use -O")
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--bundle',type=Path,default=Path(__file__).resolve().parents[1])
    p.add_argument('--report',type=Path)
    a=p.parse_args()
    result=check(a.bundle)
    text=json.dumps(result,indent=2,sort_keys=True)+'\n'
    if a.report:a.report.write_text(text,encoding='utf-8')
    print(text,end='')
