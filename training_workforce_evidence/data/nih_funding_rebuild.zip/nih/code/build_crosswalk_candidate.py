"""Build institution-only candidate files from a private logical-source config.

No source paths or record/person/award identifiers are written to candidate files.
This is a private preparation script, not a publication or rights-clearance action.
Python 3.10+, standard library only.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

IDENTITY_COLUMNS = ["institution_id", "unit_type", "ipeds_unitid", "official_name",
                    "state", "name_vintage_year", "identity_status", "universe_role"]
CROSSWALK_COLUMNS = ["nih_ipf", "fiscal_year", "actual_funding_ic", "institution_id",
                     "owner_ipeds_unitid", "contemporaneous_ipeds_unitid", "mapping_status",
                     "mapping_basis", "mapping_scope", "candidate_institution_ids",
                     "requires_private_application_scope"]
SOURCE_URLS = {
    "nih": "https://reporter.nih.gov/",
    "nih_api": "https://api.reporter.nih.gov/?urls.primaryName=V2.0",
    "ipeds": "https://nces.ed.gov/ipeds/use-the-data/download-access-database",
}
REQUIRED_SOURCES = ["institution_units", "recipient_ledger", "contribution_ownership",
                    "ownership_overrides", "nonjoint_annual", "joint_annual", "frame_windows",
                    "certified_contributions", "certified_source_gate", "legacy_recipient_links"]
ALLOWED_BASES = {"contemporaneous_recipient_ledger", "legacy_reviewed_link_fallback",
                 "unresolved_or_outside", "no_recipient_ipf", "p23_adjudicated_override"}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def csv_rows(path, encoding="utf-8-sig"):
    raw = Path(path).read_bytes()
    # IPEDS historical directories mix UTF-8/BOM and Windows-1252 exports.
    # Prefer valid UTF-8; fall back only for a directory explicitly configured
    # for legacy encoding. Decode strictly so names cannot be silently damaged.
    if encoding == "utf-8-or-cp1252":
        try:
            value = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            value = raw.decode("cp1252")
    else:
        value = raw.decode(encoding)
    return list(csv.DictReader(io.StringIO(value, newline="")))


def write_csv(path, columns, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns, extrasaction="raise", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def split_units(value):
    return {v for v in value.split(";") if v}


def public_institution_ids(inputs, registry_rows):
    """Preserve the private append-only key registry and append unseen units.

    Registry internal keys stay outside public packages. Existing assignments,
    including units absent from a later input universe, are never renumbered or
    reused. Public identities remain linkable institutional identifiers.
    """
    units = {r["unit_id"] for r in inputs["institution_units"]}
    units |= {r["owner_unit"] for r in inputs["contribution_ownership"] if r["owner_unit"]}
    units |= {r["unit_id"] for r in inputs["nonjoint_annual"]}
    units |= {r["joint_unit"] for r in inputs["joint_annual"]}
    units |= {r["unit_id"] for r in inputs["frame_windows"]}
    for row in inputs["joint_annual"]:
        units |= split_units(row["partner_units"])
    for row in inputs["institution_units"]:
        units |= split_units(row["partner_units"])
        units |= {"U" + v.removeprefix("U") for v in split_units(row["predecessor_unitids"])}
    # These approved historical carry units are already present in the identity
    # roster/predecessor union; assert this instead of silently inventing IDs.
    require({"U211361", "U212160", "U203951", "U227377", "U211644", "U116712",
             "U450979", "U197708", "U140164"} <= units,
            "Approved historical carry unit missing from the identity universe")
    mapping = {}
    identifiers = set()
    for row in registry_rows:
        require(set(row) == {"internal_unit_id", "institution_id"}, "Private registry schema differs")
        key, identifier = row["internal_unit_id"], row["institution_id"]
        require(bool(key) and key not in mapping, "Empty or duplicate private institution key")
        require(re.fullmatch(r"INST[0-9]{6}", identifier) and identifier not in identifiers,
                "Invalid or duplicate registry institutional identifier")
        mapping[key] = identifier
        identifiers.add(identifier)
    require(bool(mapping), "Existing institution registry is required")
    next_number = max(int(value[4:]) for value in identifiers) + 1
    for key in sorted(units - mapping.keys()):
        require(next_number <= 999999, "Institution registry key space exhausted")
        mapping[key] = f"INST{next_number:06d}"
        next_number += 1
    return dict(sorted(mapping.items(), key=lambda item: int(item[1][4:])))


def unitid(key):
    return key[1:] if re.fullmatch(r"U\d{6}", key) else ""


def build_identity(inputs, mapping):
    roster = {r["unit_id"]: r for r in inputs["institution_units"]}
    approved_frame = {r["unit_id"] for r in inputs["nonjoint_annual"]}
    approved_frame |= {r["joint_unit"] for r in inputs["joint_annual"]}
    source_owners = {r["owner_unit"] for r in inputs["contribution_ownership"] if r["owner_unit"]}
    partner_units = {u for r in inputs["joint_annual"] for u in split_units(r["partner_units"])}
    names = {}
    for logical_id in sorted(k for k in inputs if k.startswith("ipeds_hd_")):
        year = int(logical_id.rsplit("_", 1)[1])
        for row in inputs[logical_id]:
            key = row["UNITID"]
            if key not in names or year > names[key][0]:
                names[key] = (year, row["INSTNM"], row["STABBR"])
    rows = []
    for key, public_id in mapping.items():
        ipeds = unitid(key)
        info = roster.get(key, {})
        typ = info.get("unit_type", "ipeds_unit" if ipeds else "other_analysis_unit")
        official = names.get(ipeds)
        if official:
            year, name, state = official
            status = "official_ipeds_directory"
        else:
            year, name, state = "", "", ""
            status = ("joint_analysis_unit_name_omitted" if typ == "joint_program" else
                      "non_ipeds_label_omitted" if not ipeds else
                      "unitid_not_in_available_directories")
        roles = []
        if key in approved_frame:
            roles.append("approved_funding_frame")
        if key in source_owners:
            roles.append("observed_nih_owner")
        if key in partner_units:
            roles.append("joint_funding_partner")
        if not roles:
            roles.append("identity_or_predecessor_reference")
        rows.append(dict(zip(IDENTITY_COLUMNS, [public_id, typ, ipeds, name, state, year,
                                                status, ";".join(roles)])))
    return rows


def build_crosswalk(inputs, mapping):
    ledger = {(r["ipf"], r["fy"]): r for r in inputs["recipient_ledger"]}
    require(len(ledger) == len(inputs["recipient_ledger"]), "Recipient-year ledger key collision")
    groups = defaultdict(list)
    omitted_no_ipf = []
    for row in inputs["contribution_ownership"]:
        require(row["owner_basis"] in ALLOWED_BASES, "Unreviewed ownership-basis category")
        require(row["actual_ic"] in {"NIDA", "NIAAA"} and 2005 <= int(row["fiscal_year"]) <= 2023,
                "Unexpected contribution funding scope")
        require(not row["ipf"] or re.fullmatch(r"-?\d+", row["ipf"]),
                "Unexpected NIH recipient identifier format")
        if not row["ipf"]:
            omitted_no_ipf.append(row)
        else:
            groups[row["ipf"], row["fiscal_year"], row["actual_ic"]].append(row)
    # One override describes one historical application rather than the whole
    # recipient-year. It must not become an unconditional institution mapping.
    application_scoped = {("578422", "2013")}
    require(any(r["ipf"] == "578422" and r["first_fy"] == r["last_fy"] == "2013"
                and r["owner_unit"] == "U227377" for r in inputs["ownership_overrides"]),
            "Application-scoped adjudication evidence changed")
    rows = []
    for key, source_rows in sorted(groups.items(), key=lambda p: (int(p[0][0]), int(p[0][1]), p[0][2])):
        ipf, fy, ic = key
        owners = {r["owner_unit"] for r in source_rows}
        bases = {r["owner_basis"] for r in source_rows}
        historical_scope = (ipf, fy) in application_scoped
        has_unique_owner = len(owners) == 1 and bool(next(iter(owners)))
        assigned = next(iter(owners)) if has_unique_owner and not historical_scope else ""
        if historical_scope:
            status = "requires_private_application_scope"
            basis = "adjudicated_application_specific_override"
        elif len(owners) > 1:
            status = "ambiguous_at_recipient_fy_ic"
            basis = "mixed_contribution_ownership"
        elif assigned:
            status = "assigned_for_observed_contributions"
            basis = ("adjudicated_recipient_period_override" if "p23_adjudicated_override" in bases
                     else next(iter(bases)) if len(bases) == 1 else "mixed_contribution_ownership")
        else:
            status = "unassigned_or_outside_current_authority"
            basis = "unresolved_or_outside"
        candidates = sorted(mapping[o] for o in owners if o) if not assigned else []
        contemporary = ledger.get((ipf, fy), {}).get("contemporaneous_unitid", "")
        require(not contemporary or re.fullmatch(r"\d{6}", contemporary), "Unexpected contemporary UNITID format")
        rows.append(dict(zip(CROSSWALK_COLUMNS, [ipf, fy, ic, mapping.get(assigned, ""), unitid(assigned),
            contemporary, status, basis, "observed_certified_contributions_only", ";".join(candidates),
            str(historical_scope or len(owners) > 1).lower()])))
    return rows, groups, omitted_no_ipf


def validate_authority(inputs):
    gate = inputs["certified_source_gate"]
    require(gate.get("certified_funding_source") is True and gate.get("key_cost_ipf_mismatches") == 0,
            "Certified NIH authority gate is not passed")
    certified = {}
    for row in inputs["certified_contributions"]:
        k = (row["application_id"], row["fiscal_year"], row["actual_ic"])
        require(k not in certified, "Certified contribution-key collision")
        certified[k] = row
    current = {}
    for row in inputs["contribution_ownership"]:
        k = (row["application_id"], row["fiscal_year"], row["actual_ic"])
        require(k not in current and k in certified, "Ownership key collision or missing certified source")
        current[k] = row
        require(all(row[f] == certified[k][f] for f in ("cost_ic_usd", "ipf", "activity")),
                "Ownership/certified contribution mismatch")
    require(current.keys() == certified.keys(), "Ownership/certified keysets differ")
    ledger = {(r["ipf"], r["fy"]): r for r in inputs["recipient_ledger"]}
    legacy = {}
    for row in inputs["legacy_recipient_links"]:
        if row["sources"].startswith("joint_partner:"):
            continue
        for fy in range(max(2005, int(row["effective_start_year"])),
                        min(2023, int(row["effective_end_year"])) + 1):
            k = (row["nih_ipf"], str(fy))
            require(k not in legacy, "Legacy direct recipient-year key overlaps")
            legacy[k] = row["unit_id"]
    # Independently replay the structured decision precedence used by P2.3.
    # No copied narrative, investigator key or application key is released.
    for row in current.values():
        recipient_key = row["ipf"], row["fiscal_year"]
        historical = ledger.get(recipient_key, {})
        if historical.get("status") == "resolved" and historical.get("contemporaneous_unitid"):
            expected_owner = "U" + historical["contemporaneous_unitid"]
            expected_basis = "contemporaneous_recipient_ledger"
        elif recipient_key in legacy:
            expected_owner = legacy[recipient_key]
            expected_basis = "legacy_reviewed_link_fallback"
        else:
            expected_owner = ""
            expected_basis = "no_recipient_ipf" if not row["ipf"] else "unresolved_or_outside"
        applicable = [o for o in inputs["ownership_overrides"] if o["ipf"] == row["ipf"]
                      and int(o["first_fy"]) <= int(row["fiscal_year"]) <= int(o["last_fy"])]
        require(len(applicable) <= 1, "Recipient-period adjudications overlap")
        if applicable:
            expected_owner = applicable[0]["owner_unit"]
            expected_basis = "p23_adjudicated_override"
        require(row["owner_unit"] == expected_owner and row["owner_basis"] == expected_basis,
                "Structured ownership precedence does not replay saved current authority")
    return certified


def qa_crosswalk(inputs, rows, groups, omitted, mapping):
    inverse = {v: k for k, v in mapping.items()}
    index = {(r["nih_ipf"], r["fiscal_year"], r["actual_funding_ic"]): r for r in rows}
    exact_rows = conditional_rows = unassigned_rows = 0
    checked_dollars = 0
    for key, source_rows in groups.items():
        public = index[key]
        for source in source_rows:
            if public["requires_private_application_scope"] == "true":
                require(not public["institution_id"] and (not source["owner_unit"] or
                        mapping[source["owner_unit"]] in public["candidate_institution_ids"].split(";")),
                        "Conditional ownership collapsed")
                conditional_rows += 1
            else:
                require(inverse.get(public["institution_id"], "") == source["owner_unit"],
                        "Public projection cannot replay nonconditional saved owner")
                exact_rows += 1
                if not source["owner_unit"]:
                    unassigned_rows += 1
                checked_dollars += int(source["cost_ic_usd"])
    # History changes and split predecessors must retain separate owners.
    spot_cases = [
        ("676623", "2005", "2014", "U140164"),
        ("676623", "2015", "2023", "U486840"),
        ("3058203", "2005", "2023", "U441238"),
    ]
    spots = []
    for ipf, first, last, expected in spot_cases:
        matched = [r for r in rows if r["nih_ipf"] == ipf and int(first) <= int(r["fiscal_year"]) <= int(last)]
        require(matched and all(r["institution_id"] == mapping[expected] for r in matched),
                "Adjudicated recipient-period ownership replay failed")
        spots.append({"nih_ipf": ipf, "first_fy": first, "last_fy": last,
                      "expected_institution_id": mapping[expected], "passed": True})
    require(not any(r["nih_ipf"] == "714205" and r["institution_id"] == mapping["U186380"] for r in rows),
            "Osteopathic recipient was globally redirected to Rutgers")
    report = {
        "candidate_status": "private_pending_release_review",
        "unique_crosswalk_key_passed": len(index) == len(rows),
        "all_nonconditional_saved_owners_replayed": True,
        "structured_ownership_precedence_replayed_against_certified_contributions": True,
        "conditional_historical_override_preserved": True,
        "nih_ipf_missing_rows_are_not_imputed": True,
        "crosswalk_rows": len(rows),
        "crosswalk_status_counts": dict(Counter(r["mapping_status"] for r in rows)),
        "institution_identity_rows": len(mapping),
        "historical_override_spot_checks": spots,
        "split_predecessor_global_redirection_check_passed": True,
        "limitation": "Observed recipient-FY-actual-IC projection; not a universal recipient directory or an award-level rebuild. Conditional mappings and missing recipient IPFs require private authority.",
    }
    private = {"nonconditional_contribution_rows_replayed": exact_rows,
               "conditional_contribution_rows_excluded_from_unconditional_join": conditional_rows,
               "unassigned_nonconditional_rows_preserved": unassigned_rows,
               "missing_ipf_contribution_rows_omitted_from_crosswalk": len(omitted),
               "nonconditional_contribution_dollars_checked": checked_dollars}
    return report, private


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-config", type=Path, required=True,
                        help="Private JSON: sources maps logical IDs to path and optional expected_sha256")
    parser.add_argument("--institution-registry", type=Path, required=True,
                        help="Private append-only internal_unit_id/institution_id CSV; never copied into candidate")
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--audit-root", type=Path, required=True)
    args = parser.parse_args()
    require(args.output_root.resolve() not in args.audit_root.resolve().parents and
            args.output_root.resolve() != args.audit_root.resolve(), "Private audit must stay outside candidate")
    require(not args.output_root.resolve().is_relative_to(args.audit_root.resolve()),
            "Candidate must not be nested in its private audit tree")
    require(not args.institution_registry.resolve().is_relative_to(args.output_root.resolve()),
            "Private registry must stay outside candidate")
    require(args.institution_registry.resolve() not in {
        (args.audit_root / "institution_id_bridge_PRIVATE.csv").resolve(),
        (args.audit_root / "institution_id_registry_PRIVATE.csv").resolve()},
        "Private registry input must not equal an audit output; choose a new audit root")
    config = json.loads(args.input_config.read_text(encoding="utf-8-sig"))
    sources = config["sources"]
    require(set(REQUIRED_SOURCES) <= set(sources), "Missing required logical source")
    inputs, private_sources, public_sources = {}, [], []
    for logical_id, specification in sources.items():
        path = Path(specification["path"])
        digest = sha(path)
        require(not specification.get("expected_sha256") or specification["expected_sha256"] == digest,
                "Input hash does not match private pin: " + logical_id)
        inputs[logical_id] = (json.loads(path.read_text(encoding="utf-8-sig")) if path.suffix == ".json"
                              else csv_rows(path, specification.get("encoding", "utf-8-sig")))
        private_sources.append({"logical_source_id": logical_id, "path": str(path.resolve()), "sha256": digest})
        category = "ipeds" if logical_id.startswith("ipeds_hd_") else "nih_api" if logical_id in {
            "certified_contributions", "certified_source_gate"} else "nih" if logical_id == "recipient_ledger" else "study_authored"
        public_sources.append({"logical_source_id": logical_id, "sha256": digest,
            "source_type": category, "official_source_url": SOURCE_URLS.get(category, ""),
            "role": "official directory name/state projection" if category == "ipeds" else
                    "certified NIH factual input" if category == "nih_api" else
                    "recipient-year mapping authority" if category == "nih" else
                    "frozen institutional decision authority; private source retained outside candidate"})
    validate_authority(inputs)
    registry_rows = csv_rows(args.institution_registry)
    mapping = public_institution_ids(inputs, registry_rows)
    registry_sha = sha(args.institution_registry)
    private_sources.append({"logical_source_id": "append_only_institution_registry",
                            "path": str(args.institution_registry.resolve()), "sha256": registry_sha})
    public_sources.append({"logical_source_id": "append_only_institution_registry", "sha256": registry_sha,
        "source_type": "study_authored", "official_source_url": "",
        "role": "Private append-only registry; existing institutional IDs preserved; original internal keys not distributed"})
    identity = build_identity(inputs, mapping)
    crosswalk, groups, omitted = build_crosswalk(inputs, mapping)
    qa, private_qa = qa_crosswalk(inputs, crosswalk, groups, omitted, mapping)
    require(len(identity) == len({r["institution_id"] for r in identity}), "Identity key collision")
    for row in crosswalk:
        require(not row["institution_id"] or row["institution_id"] in {v for v in mapping.values()},
                "Crosswalk foreign-key violation")
    write_csv(args.output_root / "data/analysis_institution_identity.csv", IDENTITY_COLUMNS, identity)
    write_csv(args.output_root / "data/nih_recipient_institution_crosswalk.csv", CROSSWALK_COLUMNS, crosswalk)
    write_csv(args.output_root / "provenance/crosswalk_logical_sources.csv",
              ["logical_source_id", "sha256", "source_type", "official_source_url", "role"], public_sources)
    args.audit_root.mkdir(parents=True, exist_ok=True)
    write_csv(args.audit_root / "institution_id_bridge_PRIVATE.csv", ["internal_unit_id", "institution_id"],
              [{"internal_unit_id": k, "institution_id": v} for k, v in mapping.items()])
    write_csv(args.audit_root / "institution_id_registry_PRIVATE.csv", ["internal_unit_id", "institution_id"],
              [{"internal_unit_id": k, "institution_id": v} for k, v in mapping.items()])
    (args.audit_root / "source_hashes_PRIVATE.json").write_text(
        json.dumps(private_sources, indent=2) + "\n", encoding="utf-8")
    (args.audit_root / "crosswalk_replay_PRIVATE.json").write_text(
        json.dumps({**qa, **private_qa}, indent=2) + "\n", encoding="utf-8")
    (args.output_root / "provenance/crosswalk_qa.json").write_text(
        json.dumps(qa, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(qa, indent=2))


if __name__ == "__main__":
    main()
