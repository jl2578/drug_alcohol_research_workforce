"""Verify the candidate and reproduce funding summaries without private inputs.

Python 3.10+ standard library. Run normally (not with Python -O).
Writes optional results outside the input package; never changes candidate data.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from decimal import Decimal
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        fields = reader.fieldnames
        require(fields and len(fields) == len(set(fields)), "Invalid CSV header: " + path.name)
        rows = list(reader)
    require(all(None not in row and all(value is not None for value in row.values()) for row in rows),
            "CSV row width mismatch: " + path.name)
    return fields, rows


def write_csv(path, rows):
    require(bool(rows), "Cannot infer empty summary schema")
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def verify_manifest(bundle):
    # File inventory and hashes are checked once, by code/verify_all.py and the root SHA256SUMS.txt.
    return len([path for path in bundle.rglob("*") if path.is_file()])


def check_crosswalk(bundle, tables):
    fields, identity = tables["analysis_institution_identity.csv"]
    require(fields == ["institution_id", "unit_type", "ipeds_unitid", "official_name", "state",
                       "name_vintage_year", "identity_status", "universe_role"], "Identity schema differs")
    keys = {row["institution_id"] for row in identity}
    require(len(keys) == len(identity) == 1142, "Institution identity key/count mismatch")
    for row in identity:
        require(re.fullmatch(r"INST\d{6}", row["institution_id"]), "Invalid candidate institution key")
        require(not row["ipeds_unitid"] or re.fullmatch(r"\d{6}", row["ipeds_unitid"]), "Invalid UNITID")
        if row["official_name"]:
            require(row["ipeds_unitid"] and 2010 <= int(row["name_vintage_year"]) <= 2023,
                    "Official name lacks directory identity/version")
    fields, crosswalk = tables["nih_recipient_institution_crosswalk.csv"]
    require(fields == ["nih_ipf", "fiscal_year", "actual_funding_ic", "institution_id", "owner_ipeds_unitid",
                       "contemporaneous_ipeds_unitid", "mapping_status", "mapping_basis", "mapping_scope",
                       "candidate_institution_ids", "requires_private_application_scope"], "Crosswalk schema differs")
    index = {(r["nih_ipf"], r["fiscal_year"], r["actual_funding_ic"]) for r in crosswalk}
    require(len(index) == len(crosswalk) == 12757, "Crosswalk key/count mismatch")
    statuses = Counter()
    for row in crosswalk:
        require(re.fullmatch(r"-?\d+", row["nih_ipf"]), "Recipient IPF missing or rewritten")
        require(2005 <= int(row["fiscal_year"]) <= 2023 and row["actual_funding_ic"] in {"NIDA", "NIAAA"},
                "Invalid observed recipient year/IC")
        require(not row["institution_id"] or row["institution_id"] in keys, "Crosswalk identity reference missing")
        candidates = set(filter(None, row["candidate_institution_ids"].split(";")))
        require(candidates <= keys, "Candidate-owner reference missing")
        statuses[row["mapping_status"]] += 1
        if row["mapping_status"] == "assigned_for_observed_contributions":
            require(row["institution_id"] and row["requires_private_application_scope"] == "false", "Assigned mapping invalid")
        elif row["mapping_status"] == "requires_private_application_scope":
            require(not row["institution_id"] and row["requires_private_application_scope"] == "true" and candidates,
                    "Conditional mapping was filled or lost its candidate")
        elif row["mapping_status"] == "unassigned_or_outside_current_authority":
            require(not row["institution_id"], "Unassigned mapping has selected owner")
        else:
            raise ValueError("Unexpected mapping status in this frozen candidate")
    require(statuses == {"assigned_for_observed_contributions": 7158,
                         "unassigned_or_outside_current_authority": 5598,
                         "requires_private_application_scope": 1}, "Crosswalk statuses differ")
    return dict(status="passed", identity_rows=len(identity), mapping_rows=len(crosswalk),
                mapping_status_counts=dict(statuses), raw_contribution_allocation_reproduced=False)


def check_dictionaries_and_sanitization(bundle, tables):
    _, crossdict = read(bundle / "dictionaries/crosswalk_data_dictionary.csv")
    _, funddict = read(bundle / "dictionaries/funding_data_dictionary.csv")
    described = [(Path(row.get("file", row.get("dataset", ""))).name, row["column"])
                 for row in crossdict + funddict]
    require(len(described) == len(set(described)), "Duplicate field dictionary entry")
    expected = {(name, field) for name, (fields, _) in tables.items() for field in fields}
    require(set(described) == expected, "Dictionary/schema coverage differs")
    forbidden = re.compile(r"(^|_)(goid|pqid|person_id|pi_id|award_id|application_id|project_number|"
                           r"scientific_work_key|school_code|profile_url|abstract|carnegie)(_|$)", re.I)
    for name, (fields, rows) in tables.items():
        require(not any(forbidden.search(field) for field in fields), "Excluded identifier/source column: " + name)
        for row in rows:
            for value in row.values():
                require(not re.search(r"(?:^[A-Za-z]:[\\/]|\\\\|/Users/|/home/|proquest\.com|linkedin\.com)", value, re.I),
                        "Private path/source-profile value: " + name)
    # Scan authored candidate text/code for concrete local paths, not harmless
    # generic input-config options or references to excluded identifier types.
    for path in bundle.rglob("*"):
        if path.is_file() and path.suffix.lower() in {".md", ".py", ".json", ".csv", ".txt"}:
            text = path.read_text(encoding="utf-8-sig")
            require(not re.search(r"(?:[A-Za-z]:[\\/]Users[\\/]|/(?:Users|home)/[A-Za-z0-9][A-Za-z0-9._-]{1,}/)", text),
                    "Concrete private path in candidate: " + path.name)
    return dict(status="passed", data_files=len(tables), dictionary_fields=len(expected),
                schema_and_path_screen_passed=True,
                scope="Explicit data fields and concrete paths; not publication/disclosure clearance")


def reproduce_summaries(tables):
    source = tables["nih_source_fy_accounting.csv"][1]
    source_summary = [{"fiscal_year": row["fiscal_year"], "accounting_universe": row["accounting_universe"],
                       "actual_funding_ic": row["component"],
                       "funded_application_fy_ic_count": row["application_fy_count"],
                       "contribution_count": row["contribution_count"], "nominal_usd": row["nominal_usd"],
                       "real_2023_usd": row["real_2023_usd"]}
                      for row in source if row["component"] in {"NIDA", "NIAAA"}]
    grouped = defaultdict(list)
    for row in tables["institution_completion_year_degree_funding_exposure.csv"][1]:
        grouped[row["completion_year"], row["degree_level"]].append(row)
    grid_summary = []
    for (year, degree), rows in sorted(grouped.items()):
        known = [row for row in rows if row["exposure_status"] == "resolved"]
        values = [int(row["F_combined"]) / int(row["window_year_count"]) for row in known]
        # These are hypothetical-grid summaries, not manuscript sample support.
        grid_summary.append(dict(completion_year=year, degree_window=degree,
            grid_institutions=len(rows), resolved_institutions=len(known),
            unresolved_institutions=len(rows) - len(known),
            certified_zero_institutions=sum(row["funding_state"] == "certified_zero" for row in known),
            positive_institutions=sum(row["funding_state"] == "positive" for row in known),
            min_annualized_applications=min(values), max_annualized_applications=max(values),
            min_log1p_annualized_applications=min(map(math.log1p, values)),
            max_log1p_annualized_applications=max(map(math.log1p, values)),
            interpretation="complete hypothetical grid; not observed outcome/model sample"))
    status = Counter(row["mapping_status"] for row in tables["nih_recipient_institution_crosswalk.csv"][1])
    return source_summary, grid_summary, [{"mapping_status": key, "recipient_fy_ic_rows": value}
                                           for key, value in sorted(status.items())]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    require(__debug__, "Verification requires Python assertions enabled")
    bundle = args.bundle.resolve()
    files_checked = verify_manifest(bundle)
    tables = {path.name: read(path) for path in sorted((bundle / "data").glob("*.csv"))}
    crosswalk = check_crosswalk(bundle, tables)
    schema = check_dictionaries_and_sanitization(bundle, tables)
    sys.path.insert(0, str(bundle / "code"))
    spec = importlib.util.spec_from_file_location("candidate_funding_verifier", bundle / "code/verify_funding_candidate.py")
    funding_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(funding_module)
    funding = funding_module.check(bundle)
    source_summary, grid_summary, status_summary = reproduce_summaries(tables)
    result = dict(status="passed", files_checked=files_checked,
                  crosswalk=crosswalk, schemas=schema, funding=funding,
                  regenerated_summary_rows={"source_funding_by_fy_ic": len(source_summary),
                                            "hypothetical_exposure_grid": len(grid_summary),
                                            "mapping_status": len(status_summary)},
                  funding_contrast_log_multiplier=math.log(5) - math.log(2),
                  private_reference_comparison_performed_in_this_run=False, model_fits_performed=0,
                  limits="Candidate-only funding replay; no original allocation or outcome-model reproduction")
    if args.output_dir:
        output = args.output_dir.resolve()
        require(not output.is_relative_to(bundle), "Write reproduced outputs outside the input candidate")
        output.mkdir(parents=True, exist_ok=True)
        write_csv(output / "source_funding_by_fy_ic.csv", source_summary)
        write_csv(output / "hypothetical_funding_grid_summary.csv", grid_summary)
        write_csv(output / "crosswalk_status_summary.csv", status_summary)
        (output / "verification.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
