"""Rebuild NIH funding windows using only the sanitized candidate CSV files.

Python 3.10+ standard library. Run with --verify to compare stored outputs.
Counts add across routed source owners only because the private source audit
certifies no application/FY overlaps between those owners for these routes.
New source snapshots require that audit again before reusing this condition.
"""
from __future__ import annotations

import argparse
import csv
from decimal import Decimal, ROUND_HALF_UP, localcontext
from io import StringIO
from pathlib import Path

COMPONENTS = ("combined", "NIDA", "NIAAA", "research", "training_education_fellowship",
              "career_development", "excluded_intramural", "excluded_contract", "excluded_other")
CENT = Decimal("0.01")
METRICS = [field for c in COMPONENTS for field in
           ("F_" + c, "nominal_" + c + "_usd", "real_" + c + "_2023_usd", "contributions_" + c)] + ["F_both_IC"]
WINDOW_FIELDS = ["institution_id", "completion_year", "degree_level", "window_first_fy", "window_last_fy",
                 "window_year_count", "source_complete_fy_count", "ownership_complete_fy_count", "exposure_status",
                 "funding_state", "source_owner_reuse", *METRICS, "F_annualized_projects", "log1p_annualized_projects"]


def rows(path):
    with path.open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def table_bytes(fields, data):
    f = StringIO(newline="")
    w = csv.DictWriter(f, fieldnames=fields, lineterminator="\n", extrasaction="raise")
    w.writeheader()
    w.writerows(data)
    return f.getvalue().encode("utf-8")


def rebuild(bundle):
    if not __debug__:
        raise RuntimeError("Funding rebuild/verification requires Python assertions enabled; do not use -O")
    annual = rows(bundle / "data/institution_fy_funding.csv")
    routes = rows(bundle / "data/funding_ownership_routes.csv")
    universe = rows(bundle / "data/funding_exposure_institutions.csv")
    price = {int(r["fiscal_year"]): Decimal(r["brdpi_2023_base_100"]) for r in rows(bundle / "data/brdpi_2023_base.csv")}
    assert set(price) == set(range(2005, 2024)) and price[2023] == 100
    aidx = {(r["institution_id"], int(r["fiscal_year"])): r for r in annual}
    assert len(aidx) == len(annual)
    ridx = {}
    for r in routes:
        k = r["institution_id"], int(r["completion_year"]), int(r["fiscal_year"])
        ridx.setdefault(k, []).append(r)
    output = []
    import math
    for unit in sorted(universe, key=lambda r: r["institution_id"]):
        inst = unit["institution_id"]
        for year in range(2010, 2024):
            for level, length in (("doctoral", 5), ("masters", 2)):
                complete = unit["ownership_status"] == "resolved"
                first, last = year - length, year - 1
                chosen, reused = [], False
                for fy in range(first, last + 1):
                    route = ridx[inst, year, fy]
                    assert len({r["funding_row_institution_id"] for r in route}) == len(route)
                    reused |= len(route) > 1 or route[0]["selection_basis"] == "annual_partner_union"
                    for r in route:
                        source = aidx[r["funding_row_institution_id"], fy]
                        assert (source["exposure_status"] == "resolved") == complete
                        chosen.append(source)
                row = dict(institution_id=inst, completion_year=year, degree_level=level,
                           window_first_fy=first, window_last_fy=last, window_year_count=length,
                           source_complete_fy_count=length, ownership_complete_fy_count=length if complete else 0,
                           exposure_status="resolved" if complete else "unresolved_ownership",
                           funding_state="unresolved_ownership", source_owner_reuse=int(reused))
                with localcontext() as ctx:
                    ctx.prec = 50
                    for c in COMPONENTS:
                        for field in ("F_" + c, "nominal_" + c + "_usd", "contributions_" + c):
                            row[field] = sum(int(s[field]) for s in chosen) if complete else ""
                        real = sum((Decimal(s["nominal_" + c + "_usd"]) * price[2023] / price[int(s["fiscal_year"])] for s in chosen), Decimal(0)) if complete else None
                        row["real_" + c + "_2023_usd"] = format(real.quantize(CENT, rounding=ROUND_HALF_UP), ".2f") if complete else ""
                row["F_both_IC"] = sum(int(s["F_both_IC"]) for s in chosen) if complete else ""
                row["F_annualized_projects"] = format(row["F_combined"] / length, ".17g") if complete else ""
                row["log1p_annualized_projects"] = format(math.log1p(row["F_combined"] / length), ".17g") if complete else ""
                if complete:
                    row["funding_state"] = "positive" if row["F_combined"] else "certified_zero"
                    assert row["F_NIDA"] + row["F_NIAAA"] - row["F_both_IC"] == row["F_combined"]
                    assert sum(row["F_" + c] for c in COMPONENTS[3:]) == row["F_combined"]
                    assert sum(row["nominal_" + c + "_usd"] for c in COMPONENTS[3:]) == row["nominal_combined_usd"]
                else:
                    for c in METRICS:
                        row[c] = ""
                output.append(row)
    return table_bytes(WINDOW_FIELDS, output)


def main():
    if not __debug__:
        raise RuntimeError("Funding rebuild/verification requires Python assertions enabled; do not use -O")
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--bundle", type=Path, default=Path(__file__).resolve().parents[1])
    p.add_argument("--verify", action="store_true")
    p.add_argument("--output", type=Path, help="Optional alternate output path; never changes the source inputs")
    args = p.parse_args()
    content = rebuild(args.bundle)
    target = args.output or args.bundle / "data/institution_completion_year_degree_funding_exposure.csv"
    if args.verify:
        assert target.read_bytes() == content, "Stored exposure data differ from clean rebuild"
        print("PASS: sanitized inputs reconstruct all stored funding exposure rows byte for byte")
    else:
        target.write_bytes(content)
        print("Saved funding exposure data")


if __name__ == "__main__":
    main()
